# 校园网连接守护

校园网连接守护是在 **[demo133/campusnet](https://github.com/demo133/campusnet)** 基础上修改的 Windows 桌面应用。原作者为 **[demo133](https://github.com/demo133)** 和 campusnet contributors，本仓库保留原项目的 MIT 许可证和版权声明。

本版本主要调整了校园网认证、Windows 登录自启、托盘菜单、重连策略和窗口交互，并提供中文安装包。完整署名和组件说明见 [AUTHORS.md](AUTHORS.md)。

## 下载与安装

**[下载 Windows 安装包](https://github.com/A3697/campusnet-guardian/raw/refs/heads/main/downloads/CampusNetGuardian-20261119.1-Setup.exe)** · [SHA-256 校验值](downloads/SHA256.txt)

- 版本：`0.1.5+desktop.20261119.1`
- 系统：Windows 10 / 11，64 位
- 默认安装目录：`D:\campusnet`
- 安装包内置运行环境，不需要另行安装 Python。

本版本默认自动获取当前校园网的登录地址和认证方式，不再预设某所学校的地址。支持识别深澜 Srun、Dr.COM、锐捷等已适配的认证页面；其他学校是否可用，仍取决于其认证方式和页面结构。

1. 双击安装包，按中文向导完成安装。安装目录可以修改。
2. 打开应用，填写自己的上网账号和密码，选择运营商。
3. 插好校园网线，或连接校园 Wi-Fi，然后点击“保存并连接”。
4. 如需开机后自动登录校园网，保留“登录 Windows 后自动运行”选项。

“账号设置”中默认勾选“自动获取登录地址和认证方式”。每次连接都从当前网络的跳转页面和物理网卡的网关重新识别，保留端口、路径及页面提供的认证参数。上次学校的地址和接口参数不会用于扫描或登录其他学校；手动模式仍使用你填写的地址。开启 VPN 或虚拟网卡时，应用会读取实际物理网卡的网关、IP 和 MAC。

也可以点击“获取登录地址”查看识别结果，保存后生效。如果学校使用的页面无法识别，可取消自动获取，手动填写登录地址并选择认证方式。已联网时，学校可能不再跳转到认证页面；防火墙拦截页面、验证码或扫码认证也可能使自动登录无法完成。

安装包不包含个人账号、密码或运行日志。已有版本可以安装到原目录，原有账号和重连设置会保留。安装前请先保存正在编辑的设置。

如果系统拦截自启项登记，安装仍会完成，并在完成页提示。可打开应用查看自启状态，在系统允许后点击“开启自启”；覆盖安装会保留已经正确登记的自启命令。

## 主要功能

- 从 GitHub 检查新版本、查看更新说明、下载并安装更新。
- 自动获取登录地址、认证方式及页面提供的参数，保留手动设置方式。
- 找不到入口时可用随机 MAC 重试，需要 Windows 管理员授权，失败后恢复原设置。
- 登录 Windows 后启动托盘和后台，立即检查校园网会话并尝试认证。
- 定时检查网络，掉线后等待一段时间再尝试重连。
- 暂停或恢复自动重连，按小时和分钟分别设置自动重连时段，支持多个时段和跨午夜时段。
- 手动重新认证、检测网络、查看运行日志。
- 主窗口、账号设置和重连策略页面支持滚轮及触控板的细小滚动量；经过数字输入框时不会改变数值。
- 关闭窗口后保留托盘图标，再次打开快捷方式会回到同一个窗口。

默认每 5 分钟检查一次，发现掉线后等待 60 秒再确认并登录。这些设置可以在“重连策略”中调整。暂停和时段限制也适用于登录 Windows 时的自动认证。

密码默认显示在界面中，可取消“显示密码”隐藏。密码保存在当前 Windows 用户的凭据管理器中。

在“重连策略”中可以开启或关闭“找不到登录入口时，使用随机 MAC 重试”。新安装默认开启，已有配置可手动开启。它只在断网、自动识别失败且账号已保存时触发，每 30 分钟最多一次；正常联网、密码错误和手动地址模式不会触发。

Windows 会要求管理员授权。允许后，应用只重启当前支持 MAC 修改且启用 DHCP 的物理网卡，换一个本地随机地址，再重新查找入口和认证。联网成功后保留新地址，失败时恢复修改前的值。取消授权不会修改网卡；不支持的网卡会跳过。可点击“恢复原 MAC”恢复上次修改前的设置，这也会短暂中断网络。后台不会安装常驻管理员服务或绕过 Windows 授权。

## 更新应用

在主窗口的“软件更新”中点击“检查更新”，也可以从托盘菜单进入。发现新版本后，点击“下载并安装”并确认。下载过程中会显示进度，可以取消；文件大小和 SHA-256 校验通过后，才会启动安装程序。

更新来自本仓库的 `downloads/latest.json` 和对应安装包，使用 HTTPS 连接 GitHub。下载会使用系统代理；连接失败时会尝试直接连接和 GitHub 官方接口。网络错误、下载不完整或校验失败时，会显示原因并保留当前程序，可稍后重试。

升级安装到当前目录，保留账号、Windows 凭据、重连策略、自启项和快捷方式，完成后重新打开应用。更新期间会暂时关闭托盘和后台。安装记录位于 `profile/update-install.log`。

## 配置与卸载

配置和日志位于安装目录的 `profile` 文件夹：

| 文件 | 内容 |
| --- | --- |
| `config.json` | 账号、门户、运营商和重连设置 |
| `policy_state.json` | 暂停和恢复状态 |
| `watch.log` | 后台检查及认证记录 |
| `mac-retry-recovery.json` | 随机 MAC 修改前的网卡设置及恢复状态，不含密码 |

可以在 Windows“已安装的应用”中卸载，也可以运行安装目录中的 `unins000.exe`。卸载会关闭该目录中的应用和后台，删除程序文件、快捷方式及属于该目录的自启项。

卸载默认保留 `profile` 文件夹和 Windows 凭据，重新安装后可以继续使用原配置。

## 验证情况

本版本的自动化回归覆盖跨学校识别、细小触控板滚动量、MAC 重试和失败恢复等情况，并用 Windows 原生滚动消息对照了标准文本控件。具体结果见 [本次验证记录](release/TEST_RESULTS_20261119.md)。

本机有线网络已验证随机 MAC 更换、重新识别入口、由安装版程序完成认证以及恢复原 MAC 和重连策略。UU 远程触控板的完整传输过程、Windows 重启及其他学校的真实网络仍需现场验证。安装包尚未使用商业代码签名证书签名。

## 从源码构建

使用 Windows x64、Python 3.14 和 PowerShell 7，在仓库根目录执行：

```powershell
py -3.14 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-build.txt
.\.venv\Scripts\python.exe -m PyInstaller --noconfirm --clean CampusNetGuardian.spec
```

主程序生成在 `dist\校园网连接守护.exe`。

安装包使用 [Inno Setup 7](https://jrsoftware.org/isdl.php) 构建。安装编译器后，执行：

```powershell
.\packaging\build-installer.ps1 -Compiler 'C:\Program Files\Inno Setup 7\ISCC.exe' -Python '.\.venv\Scripts\python.exe'
```

安装包生成在 `packaging\output`。构建脚本同时生成 `downloads` 中的版本安装包、SHA-256 校验值和 `latest.json`，应将这些文件与源码一起提交到 GitHub。构建脚本只使用仓库中的空白账号模板，不会复制电脑上的个人配置。

运行测试：

```powershell
.\.venv\Scripts\python.exe -m pip install pytest==9.2.0
$env:PYTHONPATH = (Get-Location).Path
.\.venv\Scripts\python.exe -m pytest -q
```

## 原项目与许可证

- 原作者：[demo133](https://github.com/demo133)
- 原项目：[demo133/campusnet](https://github.com/demo133/campusnet)
- 本分支：[A3697/campusnet-guardian](https://github.com/A3697/campusnet-guardian)
- 应用代码：[MIT License](LICENSE)

托盘组件 pystray 采用 LGPL-3.0；它的源码与应用源码一同附在安装目录的“源码与构建.zip”中。各组件的完整许可证位于 `packaging/payload/licenses`。原项目及原作者不对本定制版本提供保证。
